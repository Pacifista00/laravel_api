<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Http\Resources\PostResource;
use Illuminate\Support\Facades\Auth;

class PostController extends Controller
{
    public function index(){
        $data = Post::all();
        return PostResource::collection($data);
    }
    public function postDetail($id){
        $post = Post::find($id);

        if(!$post){
            return response()->json(['message' => 'Post not found'], 404);
        }

        $data = Post::find($id);
        return new PostResource($data);
    }
    public function createPost(Request $request){
        $request->validate([
            'description' => 'required',
        ]);

        Post::create([
            'user_id' => Auth::user()->id,
            'description' => $request->description,
        ]);
    }
    public function updatePost(Request $request, $id){
        $request->validate([
            'description' => 'required|max:254',
        ]);

        $post = Post::find($id);

        if(!$post){
            return response()->json(['message' => 'Post not found'], 404);
        }

        if($id != Auth::user()->id){
            return response()->json(['message' => 'Post not found'], 404);
        }else{
            Post::find($id)->update([
                'description' => $request->description,
            ]);
        };
    }
}
