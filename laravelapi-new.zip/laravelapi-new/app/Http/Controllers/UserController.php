<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Http\Resources\UserResource;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function index(){
        $data = User::all();
        return UserResource::collection($data);
    }
    public function createUser(Request $request){
        $request->validate([
            'username' => 'required',
            'email' => 'required|email',
            'password' => 'required|password',
        ]);

        User::create([
            'username' => $request->username,
            'email' => $request->email,
            'password' => bcrypt($request->password),
        ]);
    }
    public function userDetail($id){
        $user = User::find($id);

        if(!$user){
            return response()->json(['message' => 'Post not found'], 404);
        }

        $data = User::find($id);
        return new UserResource($data);
    }
    public function updateUser(Request $request, $id){

        $request->validate([
            'username' => 'required|max:254',
            'email' => 'required|email|max:254',
        ]);

        $user = User::find($id);

        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }

        if($user->id != Auth::user()->id){
            return response()->json(['message' => 'User not found'], 404);
        }else{
            User::find($id)->update([
                'username' => $request->username,
                'email' => $request->email,
                'password' => bcrypt($request->password),
            ]);
        };

    }
}
